
public class ExpressionCalc {

	public static void main(String[] args) {
		int x=5, y=10;
		int e1=x+y*2;
		int e2=x-y+2;
		int e3= (x+y)*2;
		int e4= y%x;
		
	System.out.println(e1);
	System.out.println(e2);
	System.out.println(e3);
	System.out.println(e4);
	}

}
