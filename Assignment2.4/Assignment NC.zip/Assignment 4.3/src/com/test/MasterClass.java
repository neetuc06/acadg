package com.test;

public class MasterClass {

	public static void main(String[] args) {
		
	Employee emp1 = new Employee();
	emp1.setName("Anil");
	emp1.setEmpid(001);
	emp1.setDesignation("VP");
	emp1.setSalary(100000);

	emp1.display();
		
	}
}
