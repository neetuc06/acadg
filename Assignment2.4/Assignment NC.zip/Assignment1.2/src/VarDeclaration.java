
public class VarDeclaration {

	public static void main(String[] args) {
		int a, b=4, c;

	}

}
