
public class pattern {

	public static void main(String[] args) {
		for(int c=1; c<=5;c++)
		{ for (int n=1; n<=c; n++)
			{System.out.print(n);}
		System.out.println();
		;}
		
		for(int c=5; c>1;c--)
		{ for (int n=1; n<c; n++)
			{System.out.print(n);}
		System.out.println();
		;}

	}

}
